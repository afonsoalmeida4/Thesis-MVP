[![CI](https://github.com/SodaqMoja/Sodaq_wdt/workflows/CI/badge.svg)](https://github.com/SodaqMoja/Sodaq_wdt/actions?query=workflow%3ACI)

# Sodaq_wdt

Arduino library for the Watch Dog Timer.
